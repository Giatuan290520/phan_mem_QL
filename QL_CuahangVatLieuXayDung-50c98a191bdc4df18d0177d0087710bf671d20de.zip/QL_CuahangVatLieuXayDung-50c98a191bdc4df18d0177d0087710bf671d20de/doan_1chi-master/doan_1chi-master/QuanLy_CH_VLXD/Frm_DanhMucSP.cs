﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLy_CH_VLXD
{
    public partial class Frm_DanhMucSP : UserControl
    {
        public Frm_DanhMucSP()
        {
            InitializeComponent();
        }
    }
}
