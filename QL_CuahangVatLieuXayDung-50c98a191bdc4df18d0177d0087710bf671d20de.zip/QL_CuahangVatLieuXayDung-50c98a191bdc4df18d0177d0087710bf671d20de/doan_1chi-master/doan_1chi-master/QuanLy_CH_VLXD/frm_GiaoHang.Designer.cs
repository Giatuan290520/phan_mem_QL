﻿namespace QuanLy_CH_VLXD
{
    partial class frm_GiaoHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.groupBox_TTCTSanPham = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_TenKH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_SDT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_MaGiaoHang = new System.Windows.Forms.TextBox();
            this.lbl_Manv = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox_TTCTSanPham.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 303);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1320, 428);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách mặt hàng";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 48);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(581, 224);
            this.dataGridView1.TabIndex = 0;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(559, 124);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(230, 27);
            this.comboBox4.TabIndex = 74;
            // 
            // groupBox_TTCTSanPham
            // 
            this.groupBox_TTCTSanPham.Controls.Add(this.label8);
            this.groupBox_TTCTSanPham.Controls.Add(this.comboBox1);
            this.groupBox_TTCTSanPham.Controls.Add(this.label6);
            this.groupBox_TTCTSanPham.Controls.Add(this.button4);
            this.groupBox_TTCTSanPham.Controls.Add(this.button3);
            this.groupBox_TTCTSanPham.Controls.Add(this.button1);
            this.groupBox_TTCTSanPham.Controls.Add(this.label16);
            this.groupBox_TTCTSanPham.Controls.Add(this.label4);
            this.groupBox_TTCTSanPham.Controls.Add(this.textBox4);
            this.groupBox_TTCTSanPham.Controls.Add(this.comboBox4);
            this.groupBox_TTCTSanPham.Controls.Add(this.label12);
            this.groupBox_TTCTSanPham.Controls.Add(this.label5);
            this.groupBox_TTCTSanPham.Controls.Add(this.dateTimePicker2);
            this.groupBox_TTCTSanPham.Controls.Add(this.label7);
            this.groupBox_TTCTSanPham.Controls.Add(this.label14);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TenKH);
            this.groupBox_TTCTSanPham.Controls.Add(this.label1);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SDT);
            this.groupBox_TTCTSanPham.Controls.Add(this.label3);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_MaGiaoHang);
            this.groupBox_TTCTSanPham.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_TTCTSanPham.Location = new System.Drawing.Point(25, 49);
            this.groupBox_TTCTSanPham.Name = "groupBox_TTCTSanPham";
            this.groupBox_TTCTSanPham.Size = new System.Drawing.Size(1320, 248);
            this.groupBox_TTCTSanPham.TabIndex = 4;
            this.groupBox_TTCTSanPham.TabStop = false;
            this.groupBox_TTCTSanPham.Text = "Thông tin chi tiết mặt hàng";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(559, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 19);
            this.label8.TabIndex = 83;
            this.label8.Text = "1000000000";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(148, 169);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(230, 27);
            this.comboBox1.TabIndex = 82;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 19);
            this.label6.TabIndex = 81;
            this.label6.Text = "Hóa đơn";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(907, 100);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 35);
            this.button4.TabIndex = 80;
            this.button4.Text = "Cập nhật";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(907, 164);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 35);
            this.button3.TabIndex = 79;
            this.button3.Text = "Xóa";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(907, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 35);
            this.button1.TabIndex = 78;
            this.button1.Text = "Thêm";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(746, 175);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 19);
            this.label16.TabIndex = 77;
            this.label16.Text = "VND";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(427, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 19);
            this.label4.TabIndex = 76;
            this.label4.Text = "Số lượng giao";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(559, 32);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(230, 27);
            this.textBox4.TabIndex = 75;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(427, 132);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 73;
            this.label12.Text = "Tình trạng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(427, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 19);
            this.label5.TabIndex = 68;
            this.label5.Text = "Tổng tiền giao hàng";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(559, 79);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(230, 26);
            this.dateTimePicker2.TabIndex = 66;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(427, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 19);
            this.label7.TabIndex = 65;
            this.label7.Text = "Ngày giao hàng";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(31, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 19);
            this.label14.TabIndex = 58;
            this.label14.Text = "Tên khách hàng";
            // 
            // txt_TenKH
            // 
            this.txt_TenKH.Location = new System.Drawing.Point(148, 124);
            this.txt_TenKH.Multiline = true;
            this.txt_TenKH.Name = "txt_TenKH";
            this.txt_TenKH.Size = new System.Drawing.Size(230, 27);
            this.txt_TenKH.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 19);
            this.label1.TabIndex = 56;
            this.label1.Text = "Số điện thoại";
            // 
            // txt_SDT
            // 
            this.txt_SDT.Location = new System.Drawing.Point(148, 77);
            this.txt_SDT.Multiline = true;
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Size = new System.Drawing.Size(230, 27);
            this.txt_SDT.TabIndex = 55;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 19);
            this.label3.TabIndex = 52;
            this.label3.Text = "Mã giao hàng";
            // 
            // txt_MaGiaoHang
            // 
            this.txt_MaGiaoHang.Location = new System.Drawing.Point(148, 32);
            this.txt_MaGiaoHang.Multiline = true;
            this.txt_MaGiaoHang.Name = "txt_MaGiaoHang";
            this.txt_MaGiaoHang.Size = new System.Drawing.Size(230, 27);
            this.txt_MaGiaoHang.TabIndex = 51;
            // 
            // lbl_Manv
            // 
            this.lbl_Manv.AutoSize = true;
            this.lbl_Manv.Location = new System.Drawing.Point(42, 14);
            this.lbl_Manv.Name = "lbl_Manv";
            this.lbl_Manv.Size = new System.Drawing.Size(72, 13);
            this.lbl_Manv.TabIndex = 54;
            this.lbl_Manv.Text = "Mã nhân viên";
            // 
            // frm_GiaoHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_TTCTSanPham);
            this.Controls.Add(this.lbl_Manv);
            this.Name = "frm_GiaoHang";
            this.Size = new System.Drawing.Size(1419, 753);
            this.Load += new System.EventHandler(this.frm_GiaoHang_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox_TTCTSanPham.ResumeLayout(false);
            this.groupBox_TTCTSanPham.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.GroupBox groupBox_TTCTSanPham;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_TenKH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_SDT;
        private System.Windows.Forms.Label lbl_Manv;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_MaGiaoHang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
    }
}