﻿namespace QuanLy_CH_VLXD
{
    partial class frm_BanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_InHoaDon = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_MaHDB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Manv = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Tenkh = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox_TTCTSanPham = new System.Windows.Forms.GroupBox();
            this.btn_themKH = new System.Windows.Forms.Button();
            this.lbl_Tongtien = new System.Windows.Forms.Label();
            this.lbl_SoLuong = new System.Windows.Forms.Label();
            this.txt_SoLuong = new System.Windows.Forms.TextBox();
            this.txt_TinhTrang = new System.Windows.Forms.TextBox();
            this.btn_Xoa = new System.Windows.Forms.Button();
            this.btn_Sua = new System.Windows.Forms.Button();
            this.btn_Them = new System.Windows.Forms.Button();
            this.btn_LamMoi = new System.Windows.Forms.Button();
            this.txt_SDT = new System.Windows.Forms.TextBox();
            this.cbo_TenMatHang = new System.Windows.Forms.ComboBox();
            this.cbo_NSX = new System.Windows.Forms.ComboBox();
            this.lbl_vnd = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cbo_LoaiMatHang = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_DonViTinh = new System.Windows.Forms.TextBox();
            this.lbl_tTien = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.lbl_NgayLap = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_DonGia = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView_HDB = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_CTHoaDonBan = new System.Windows.Forms.DataGridView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox_TTCTSanPham.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_HDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTHoaDonBan)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_InHoaDon
            // 
            this.btn_InHoaDon.Location = new System.Drawing.Point(742, 215);
            this.btn_InHoaDon.Name = "btn_InHoaDon";
            this.btn_InHoaDon.Size = new System.Drawing.Size(99, 35);
            this.btn_InHoaDon.TabIndex = 24;
            this.btn_InHoaDon.Text = "In hóa đơn";
            this.btn_InHoaDon.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 19);
            this.label4.TabIndex = 50;
            this.label4.Text = "Tên loại mặt hàng";
            // 
            // txt_MaHDB
            // 
            this.txt_MaHDB.Location = new System.Drawing.Point(148, 32);
            this.txt_MaHDB.Multiline = true;
            this.txt_MaHDB.Name = "txt_MaHDB";
            this.txt_MaHDB.Size = new System.Drawing.Size(230, 27);
            this.txt_MaHDB.TabIndex = 51;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 19);
            this.label3.TabIndex = 52;
            this.label3.Text = "Mã hóa đơn bán";
            // 
            // lbl_Manv
            // 
            this.lbl_Manv.AutoSize = true;
            this.lbl_Manv.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbl_Manv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Manv.Location = new System.Drawing.Point(0, 0);
            this.lbl_Manv.Name = "lbl_Manv";
            this.lbl_Manv.Size = new System.Drawing.Size(101, 19);
            this.lbl_Manv.TabIndex = 54;
            this.lbl_Manv.Text = "Mã nhân viên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 19);
            this.label1.TabIndex = 56;
            this.label1.Text = "Số điện thoại";
            // 
            // txt_Tenkh
            // 
            this.txt_Tenkh.Location = new System.Drawing.Point(148, 124);
            this.txt_Tenkh.Name = "txt_Tenkh";
            this.txt_Tenkh.Size = new System.Drawing.Size(230, 26);
            this.txt_Tenkh.TabIndex = 57;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(31, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 19);
            this.label14.TabIndex = 58;
            this.label14.Text = "Tên khách hàng";
            // 
            // groupBox_TTCTSanPham
            // 
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_themKH);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_Tongtien);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_InHoaDon);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TinhTrang);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Xoa);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Sua);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Them);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_LamMoi);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SDT);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_TenMatHang);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_NSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_vnd);
            this.groupBox_TTCTSanPham.Controls.Add(this.label12);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_LoaiMatHang);
            this.groupBox_TTCTSanPham.Controls.Add(this.label10);
            this.groupBox_TTCTSanPham.Controls.Add(this.label9);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonViTinh);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_tTien);
            this.groupBox_TTCTSanPham.Controls.Add(this.dateTimePicker2);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_NgayLap);
            this.groupBox_TTCTSanPham.Controls.Add(this.label6);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonGia);
            this.groupBox_TTCTSanPham.Controls.Add(this.label11);
            this.groupBox_TTCTSanPham.Controls.Add(this.label14);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_Tenkh);
            this.groupBox_TTCTSanPham.Controls.Add(this.label1);
            this.groupBox_TTCTSanPham.Controls.Add(this.label3);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_MaHDB);
            this.groupBox_TTCTSanPham.Controls.Add(this.label4);
            this.groupBox_TTCTSanPham.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_TTCTSanPham.Location = new System.Drawing.Point(12, 22);
            this.groupBox_TTCTSanPham.Name = "groupBox_TTCTSanPham";
            this.groupBox_TTCTSanPham.Size = new System.Drawing.Size(1333, 266);
            this.groupBox_TTCTSanPham.TabIndex = 2;
            this.groupBox_TTCTSanPham.TabStop = false;
            this.groupBox_TTCTSanPham.Text = "Thông tin chi tiết mặt hàng";
            this.groupBox_TTCTSanPham.Enter += new System.EventHandler(this.groupBox_TTCTSanPham_Enter);
            // 
            // btn_themKH
            // 
            this.btn_themKH.Location = new System.Drawing.Point(893, 215);
            this.btn_themKH.Name = "btn_themKH";
            this.btn_themKH.Size = new System.Drawing.Size(99, 35);
            this.btn_themKH.TabIndex = 89;
            this.btn_themKH.Text = "Thêm khách hàng";
            this.btn_themKH.UseVisualStyleBackColor = true;
            this.btn_themKH.Click += new System.EventHandler(this.btn_themKH_Click);
            // 
            // lbl_Tongtien
            // 
            this.lbl_Tongtien.AutoSize = true;
            this.lbl_Tongtien.Location = new System.Drawing.Point(1062, 174);
            this.lbl_Tongtien.Name = "lbl_Tongtien";
            this.lbl_Tongtien.Size = new System.Drawing.Size(81, 19);
            this.lbl_Tongtien.TabIndex = 88;
            this.lbl_Tongtien.Text = "100000000";
            // 
            // lbl_SoLuong
            // 
            this.lbl_SoLuong.AutoSize = true;
            this.lbl_SoLuong.Location = new System.Drawing.Point(966, 85);
            this.lbl_SoLuong.Name = "lbl_SoLuong";
            this.lbl_SoLuong.Size = new System.Drawing.Size(64, 19);
            this.lbl_SoLuong.TabIndex = 86;
            this.lbl_SoLuong.Text = "Số lượng";
            // 
            // txt_SoLuong
            // 
            this.txt_SoLuong.Location = new System.Drawing.Point(1066, 77);
            this.txt_SoLuong.Multiline = true;
            this.txt_SoLuong.Name = "txt_SoLuong";
            this.txt_SoLuong.Size = new System.Drawing.Size(230, 27);
            this.txt_SoLuong.TabIndex = 85;
            this.txt_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_SoLuong_KeyPress);
            // 
            // txt_TinhTrang
            // 
            this.txt_TinhTrang.Location = new System.Drawing.Point(1066, 34);
            this.txt_TinhTrang.Multiline = true;
            this.txt_TinhTrang.Name = "txt_TinhTrang";
            this.txt_TinhTrang.Size = new System.Drawing.Size(230, 27);
            this.txt_TinhTrang.TabIndex = 84;
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.Location = new System.Drawing.Point(445, 215);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(99, 35);
            this.btn_Xoa.TabIndex = 83;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.UseVisualStyleBackColor = true;
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // btn_Sua
            // 
            this.btn_Sua.Location = new System.Drawing.Point(306, 215);
            this.btn_Sua.Name = "btn_Sua";
            this.btn_Sua.Size = new System.Drawing.Size(99, 35);
            this.btn_Sua.TabIndex = 82;
            this.btn_Sua.Text = "Sửa";
            this.btn_Sua.UseVisualStyleBackColor = true;
            this.btn_Sua.Click += new System.EventHandler(this.btn_Sua_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.Location = new System.Drawing.Point(166, 215);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(99, 35);
            this.btn_Them.TabIndex = 81;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.UseVisualStyleBackColor = true;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // btn_LamMoi
            // 
            this.btn_LamMoi.Location = new System.Drawing.Point(596, 215);
            this.btn_LamMoi.Name = "btn_LamMoi";
            this.btn_LamMoi.Size = new System.Drawing.Size(99, 35);
            this.btn_LamMoi.TabIndex = 79;
            this.btn_LamMoi.Text = "Làm mới";
            this.btn_LamMoi.UseVisualStyleBackColor = true;
            this.btn_LamMoi.Click += new System.EventHandler(this.btn_LamMoi_Click);
            // 
            // txt_SDT
            // 
            this.txt_SDT.Location = new System.Drawing.Point(148, 81);
            this.txt_SDT.Multiline = true;
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Size = new System.Drawing.Size(230, 27);
            this.txt_SDT.TabIndex = 78;
            this.txt_SDT.TextChanged += new System.EventHandler(this.txt_SDT_TextChanged);
            this.txt_SDT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_SDT_KeyDown);
            // 
            // cbo_TenMatHang
            // 
            this.cbo_TenMatHang.FormattingEnabled = true;
            this.cbo_TenMatHang.Location = new System.Drawing.Point(625, 31);
            this.cbo_TenMatHang.Name = "cbo_TenMatHang";
            this.cbo_TenMatHang.Size = new System.Drawing.Size(230, 27);
            this.cbo_TenMatHang.TabIndex = 77;
            this.cbo_TenMatHang.SelectedIndexChanged += new System.EventHandler(this.cbo_TenMatHang_SelectedIndexChanged);
            this.cbo_TenMatHang.SelectedValueChanged += new System.EventHandler(this.cbo_TenMatHang_SelectedValueChanged);
            this.cbo_TenMatHang.TextChanged += new System.EventHandler(this.cbo_TenMatHang_TextChanged);
            // 
            // cbo_NSX
            // 
            this.cbo_NSX.FormattingEnabled = true;
            this.cbo_NSX.Location = new System.Drawing.Point(625, 166);
            this.cbo_NSX.Name = "cbo_NSX";
            this.cbo_NSX.Size = new System.Drawing.Size(230, 27);
            this.cbo_NSX.TabIndex = 76;
            // 
            // lbl_vnd
            // 
            this.lbl_vnd.AutoSize = true;
            this.lbl_vnd.Location = new System.Drawing.Point(1253, 174);
            this.lbl_vnd.Name = "lbl_vnd";
            this.lbl_vnd.Size = new System.Drawing.Size(43, 19);
            this.lbl_vnd.TabIndex = 75;
            this.lbl_vnd.Text = "VND";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(966, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 73;
            this.label12.Text = "Tình trạng";
            // 
            // cbo_LoaiMatHang
            // 
            this.cbo_LoaiMatHang.FormattingEnabled = true;
            this.cbo_LoaiMatHang.Location = new System.Drawing.Point(148, 171);
            this.cbo_LoaiMatHang.Name = "cbo_LoaiMatHang";
            this.cbo_LoaiMatHang.Size = new System.Drawing.Size(230, 27);
            this.cbo_LoaiMatHang.TabIndex = 72;
            this.cbo_LoaiMatHang.SelectedValueChanged += new System.EventHandler(this.cbo_LoaiMatHang_SelectedValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(506, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 71;
            this.label10.Text = "Nhà sản xuất";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(506, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 70;
            this.label9.Text = "Đơn vị tính";
            // 
            // txt_DonViTinh
            // 
            this.txt_DonViTinh.Enabled = false;
            this.txt_DonViTinh.Location = new System.Drawing.Point(625, 123);
            this.txt_DonViTinh.Multiline = true;
            this.txt_DonViTinh.Name = "txt_DonViTinh";
            this.txt_DonViTinh.Size = new System.Drawing.Size(230, 27);
            this.txt_DonViTinh.TabIndex = 69;
            // 
            // lbl_tTien
            // 
            this.lbl_tTien.AutoSize = true;
            this.lbl_tTien.Location = new System.Drawing.Point(966, 174);
            this.lbl_tTien.Name = "lbl_tTien";
            this.lbl_tTien.Size = new System.Drawing.Size(65, 19);
            this.lbl_tTien.TabIndex = 68;
            this.lbl_tTien.Text = "Tổng tiền";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Enabled = false;
            this.dateTimePicker2.Location = new System.Drawing.Point(1066, 124);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(230, 26);
            this.dateTimePicker2.TabIndex = 66;
            // 
            // lbl_NgayLap
            // 
            this.lbl_NgayLap.AutoSize = true;
            this.lbl_NgayLap.Location = new System.Drawing.Point(966, 131);
            this.lbl_NgayLap.Name = "lbl_NgayLap";
            this.lbl_NgayLap.Size = new System.Drawing.Size(64, 19);
            this.lbl_NgayLap.TabIndex = 65;
            this.lbl_NgayLap.Text = "Ngày lập";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(506, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 19);
            this.label6.TabIndex = 64;
            this.label6.Text = "Đơn giá bán";
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.Enabled = false;
            this.txt_DonGia.Location = new System.Drawing.Point(625, 77);
            this.txt_DonGia.Multiline = true;
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.Size = new System.Drawing.Size(230, 27);
            this.txt_DonGia.TabIndex = 63;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(506, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 19);
            this.label11.TabIndex = 62;
            this.label11.Text = "Tên mặt hàng";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView_HDB);
            this.groupBox1.Controls.Add(this.dataGridView_CTHoaDonBan);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 310);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1333, 369);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin mua hàng";
            // 
            // dataGridView_HDB
            // 
            this.dataGridView_HDB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_HDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_HDB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column7,
            this.Column6});
            this.dataGridView_HDB.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridView_HDB.Location = new System.Drawing.Point(596, 21);
            this.dataGridView_HDB.Name = "dataGridView_HDB";
            this.dataGridView_HDB.Size = new System.Drawing.Size(734, 345);
            this.dataGridView_HDB.TabIndex = 2;
            this.dataGridView_HDB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_HDB_CellClick);
            this.dataGridView_HDB.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_HDB_CellContentClick);
            this.dataGridView_HDB.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_HDB_CellMouseClick);
            this.dataGridView_HDB.Paint += new System.Windows.Forms.PaintEventHandler(this.dataGridView_HDB_Paint);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "MAHDB1";
            this.Column1.HeaderText = "Mã HDB";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "MANV1";
            this.Column2.HeaderText = "Mã NV";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "SDT1";
            this.Column3.HeaderText = "SĐT";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "HOTENKH1";
            this.Column4.HeaderText = "Họ tên KH";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "NGAYLAP1";
            this.Column5.HeaderText = "Ngày lập";
            this.Column5.Name = "Column5";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "TONGSLSANPHAM1";
            this.Column7.HeaderText = "Tổng sản phầm";
            this.Column7.Name = "Column7";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "TONGTIEN1";
            this.Column6.HeaderText = "Tổng tiền";
            this.Column6.Name = "Column6";
            // 
            // dataGridView_CTHoaDonBan
            // 
            this.dataGridView_CTHoaDonBan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_CTHoaDonBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_CTHoaDonBan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12});
            this.dataGridView_CTHoaDonBan.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView_CTHoaDonBan.Location = new System.Drawing.Point(3, 21);
            this.dataGridView_CTHoaDonBan.Name = "dataGridView_CTHoaDonBan";
            this.dataGridView_CTHoaDonBan.Size = new System.Drawing.Size(585, 345);
            this.dataGridView_CTHoaDonBan.TabIndex = 0;
            this.dataGridView_CTHoaDonBan.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_CTHoaDonBan_CellMouseClick);
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "MACTHDB1";
            this.Column8.HeaderText = "Mã CTHDB";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "TENMATHANG1";
            this.Column9.HeaderText = "Tên mặt hàng";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "SOLUONGBAN1";
            this.Column10.HeaderText = "Số lượng bán";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "GIA1";
            this.Column11.HeaderText = "Gía";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "THANHTIEN1";
            this.Column12.HeaderText = "Thành tiền";
            this.Column12.Name = "Column12";
            // 
            // frm_BanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_TTCTSanPham);
            this.Controls.Add(this.lbl_Manv);
            this.Name = "frm_BanHang";
            this.Size = new System.Drawing.Size(1354, 710);
            this.Load += new System.EventHandler(this.frm_BanHang_Load);
            this.groupBox_TTCTSanPham.ResumeLayout(false);
            this.groupBox_TTCTSanPham.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_HDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTHoaDonBan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_InHoaDon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_MaHDB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_Manv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Tenkh;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox_TTCTSanPham;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_vnd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbo_LoaiMatHang;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_DonViTinh;
        private System.Windows.Forms.Label lbl_tTien;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label lbl_NgayLap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_DonGia;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbo_TenMatHang;
        private System.Windows.Forms.ComboBox cbo_NSX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_SDT;
        private System.Windows.Forms.Button btn_Xoa;
        private System.Windows.Forms.Button btn_Sua;
        private System.Windows.Forms.Button btn_Them;
        private System.Windows.Forms.Button btn_LamMoi;
        private System.Windows.Forms.DataGridView dataGridView_CTHoaDonBan;
        private System.Windows.Forms.TextBox txt_TinhTrang;
        private System.Windows.Forms.Label lbl_SoLuong;
        private System.Windows.Forms.TextBox txt_SoLuong;
        private System.Windows.Forms.Label lbl_Tongtien;
        private System.Windows.Forms.DataGridView dataGridView_HDB;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.Button btn_themKH;
    }
}