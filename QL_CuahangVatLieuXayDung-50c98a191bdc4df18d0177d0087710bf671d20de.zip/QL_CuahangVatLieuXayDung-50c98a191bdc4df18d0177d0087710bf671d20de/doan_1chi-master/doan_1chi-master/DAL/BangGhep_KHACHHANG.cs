﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BangGhep_KHACHHANG
    {
        private String MAKH;
        private String TENLOAIKH;
        private String HOTENKH;
        private String SDT;
        private String DIACHI;
        public string MAKH1 { get => MAKH; set => MAKH = value; }
        public string TENLOAIKH1 { get => TENLOAIKH; set => TENLOAIKH = value; }
        public string HOTENKH1 { get => HOTENKH; set => HOTENKH = value; }
        public string SDT1 { get => SDT; set => SDT = value; }
        public string DIACHI1 { get => DIACHI; set => DIACHI = value; }
    }
}
