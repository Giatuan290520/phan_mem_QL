﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BangGhep_DatHangNSX
    {
        String MAPDHNSX;
        String MANV;
        String TENNSX;
        String NGAYLAP;
        String TONGTIENHANGDAT;
        String SOTIENTRATRUOC;
       // String SOTIENCONLAII;

        public string MAPDHNSX1 { get => MAPDHNSX; set => MAPDHNSX = value; }
        public string MANV1 { get => MANV; set => MANV = value; }
        public string TENNSX1 { get => TENNSX; set => TENNSX = value; }
        public string NGAYLAP1 { get => NGAYLAP; set => NGAYLAP = value; }
        public string TONGTIENHANGDAT1 { get => TONGTIENHANGDAT; set => TONGTIENHANGDAT = value; }
        public string SOTIENTRATRUOC1 { get => SOTIENTRATRUOC; set => SOTIENTRATRUOC = value; }
       // public string SOTIENCONLAII1 { get => SOTIENCONLAII; set => SOTIENCONLAII = value; }



    }
}
