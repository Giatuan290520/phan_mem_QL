﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_TTNhanVien
    {
        linQDataContext Dal_data = new linQDataContext();
        


    }
}

