﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class CHITIET_DATHANGNSX
    {
        String MACTPHIEUDATHANG;
        String TENMATHANG;
        String SOLUONG;
        String GIA;
        String THANHTIEN;

        public string MACTPHIEUDATHANG1 { get => MACTPHIEUDATHANG; set => MACTPHIEUDATHANG = value; }
        public string TENMATHANG1 { get => TENMATHANG; set => TENMATHANG = value; }
        public string SOLUONG1 { get => SOLUONG; set => SOLUONG = value; }
        public string GIA1 { get => GIA; set => GIA = value; }
        public string THANHTIEN1 { get => THANHTIEN; set => THANHTIEN = value; }
    }
}
