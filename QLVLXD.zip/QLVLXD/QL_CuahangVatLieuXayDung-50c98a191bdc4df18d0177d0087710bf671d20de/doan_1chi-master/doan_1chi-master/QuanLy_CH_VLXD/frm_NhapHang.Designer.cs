﻿namespace QuanLy_CH_VLXD
{
    partial class frm_NhapHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_TTCTSanPham = new System.Windows.Forms.GroupBox();
            this.txt_TenMH = new System.Windows.Forms.TextBox();
            this.txt_TenLoaiMH = new System.Windows.Forms.TextBox();
            this.txt_NSX = new System.Windows.Forms.TextBox();
            this.cbo_chitietPDNSX = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbo_maPNNSX = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_PhieuNhap = new System.Windows.Forms.TextBox();
            this.btn_LamMoi = new System.Windows.Forms.Button();
            this.btn_them = new System.Windows.Forms.Button();
            this.cbo_TinhTrang = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_DVT = new System.Windows.Forms.Label();
            this.txt_DonViTinh = new System.Windows.Forms.TextBox();
            this.lbl_SoLuong = new System.Windows.Forms.Label();
            this.txt_SoLuong = new System.Windows.Forms.TextBox();
            this.dateTimePicker_NhayNhap = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_DonGiaNhap = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_manv = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView_CTnhaphang = new System.Windows.Forms.DataGridView();
            this.dataGridView_nhaphang = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox_TTCTSanPham.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTnhaphang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_nhaphang)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_TTCTSanPham
            // 
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TenMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TenLoaiMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_NSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_chitietPDNSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.label1);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_maPNNSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.label13);
            this.groupBox_TTCTSanPham.Controls.Add(this.label6);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_PhieuNhap);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_LamMoi);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_them);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_TinhTrang);
            this.groupBox_TTCTSanPham.Controls.Add(this.label12);
            this.groupBox_TTCTSanPham.Controls.Add(this.label10);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_DVT);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonViTinh);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.dateTimePicker_NhayNhap);
            this.groupBox_TTCTSanPham.Controls.Add(this.label7);
            this.groupBox_TTCTSanPham.Controls.Add(this.label5);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonGiaNhap);
            this.groupBox_TTCTSanPham.Controls.Add(this.label3);
            this.groupBox_TTCTSanPham.Controls.Add(this.label2);
            this.groupBox_TTCTSanPham.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_TTCTSanPham.Location = new System.Drawing.Point(24, 31);
            this.groupBox_TTCTSanPham.Name = "groupBox_TTCTSanPham";
            this.groupBox_TTCTSanPham.Size = new System.Drawing.Size(1320, 274);
            this.groupBox_TTCTSanPham.TabIndex = 1;
            this.groupBox_TTCTSanPham.TabStop = false;
            this.groupBox_TTCTSanPham.Text = "Thông tin mặt hàng";
            // 
            // txt_TenMH
            // 
            this.txt_TenMH.Location = new System.Drawing.Point(555, 127);
            this.txt_TenMH.Multiline = true;
            this.txt_TenMH.Name = "txt_TenMH";
            this.txt_TenMH.Size = new System.Drawing.Size(230, 27);
            this.txt_TenMH.TabIndex = 38;
            // 
            // txt_TenLoaiMH
            // 
            this.txt_TenLoaiMH.Location = new System.Drawing.Point(555, 79);
            this.txt_TenLoaiMH.Multiline = true;
            this.txt_TenLoaiMH.Name = "txt_TenLoaiMH";
            this.txt_TenLoaiMH.Size = new System.Drawing.Size(230, 27);
            this.txt_TenLoaiMH.TabIndex = 37;
            // 
            // txt_NSX
            // 
            this.txt_NSX.Location = new System.Drawing.Point(555, 35);
            this.txt_NSX.Multiline = true;
            this.txt_NSX.Name = "txt_NSX";
            this.txt_NSX.Size = new System.Drawing.Size(230, 27);
            this.txt_NSX.TabIndex = 36;
            // 
            // cbo_chitietPDNSX
            // 
            this.cbo_chitietPDNSX.FormattingEnabled = true;
            this.cbo_chitietPDNSX.Location = new System.Drawing.Point(158, 127);
            this.cbo_chitietPDNSX.Name = "cbo_chitietPDNSX";
            this.cbo_chitietPDNSX.Size = new System.Drawing.Size(230, 27);
            this.cbo_chitietPDNSX.TabIndex = 35;
            this.cbo_chitietPDNSX.SelectedIndexChanged += new System.EventHandler(this.cbo_chitietPDNSX_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 19);
            this.label1.TabIndex = 34;
            this.label1.Text = "Mã chi tiết PDNSX";
            // 
            // cbo_maPNNSX
            // 
            this.cbo_maPNNSX.FormattingEnabled = true;
            this.cbo_maPNNSX.Location = new System.Drawing.Point(158, 79);
            this.cbo_maPNNSX.Name = "cbo_maPNNSX";
            this.cbo_maPNNSX.Size = new System.Drawing.Size(230, 27);
            this.cbo_maPNNSX.TabIndex = 33;
            this.cbo_maPNNSX.SelectedIndexChanged += new System.EventHandler(this.cbo_maPNNSX_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 19);
            this.label13.TabIndex = 32;
            this.label13.Text = "Mã phiếu đặt NSX";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 19);
            this.label6.TabIndex = 28;
            this.label6.Text = "Mã phiếu nhập";
            // 
            // txt_PhieuNhap
            // 
            this.txt_PhieuNhap.Enabled = false;
            this.txt_PhieuNhap.Location = new System.Drawing.Point(158, 35);
            this.txt_PhieuNhap.Multiline = true;
            this.txt_PhieuNhap.Name = "txt_PhieuNhap";
            this.txt_PhieuNhap.Size = new System.Drawing.Size(230, 27);
            this.txt_PhieuNhap.TabIndex = 27;
            // 
            // btn_LamMoi
            // 
            this.btn_LamMoi.Location = new System.Drawing.Point(1033, 206);
            this.btn_LamMoi.Name = "btn_LamMoi";
            this.btn_LamMoi.Size = new System.Drawing.Size(99, 35);
            this.btn_LamMoi.TabIndex = 25;
            this.btn_LamMoi.Text = "Làm mới";
            this.btn_LamMoi.UseVisualStyleBackColor = true;
            // 
            // btn_them
            // 
            this.btn_them.Location = new System.Drawing.Point(863, 206);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(99, 35);
            this.btn_them.TabIndex = 24;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = true;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // cbo_TinhTrang
            // 
            this.cbo_TinhTrang.FormattingEnabled = true;
            this.cbo_TinhTrang.Location = new System.Drawing.Point(940, 127);
            this.cbo_TinhTrang.Name = "cbo_TinhTrang";
            this.cbo_TinhTrang.Size = new System.Drawing.Size(230, 27);
            this.cbo_TinhTrang.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(859, 135);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 22;
            this.label12.Text = "Tình trạng";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(434, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 18;
            this.label10.Text = "Nhà sản xuất";
            // 
            // lbl_DVT
            // 
            this.lbl_DVT.AutoSize = true;
            this.lbl_DVT.Location = new System.Drawing.Point(859, 45);
            this.lbl_DVT.Name = "lbl_DVT";
            this.lbl_DVT.Size = new System.Drawing.Size(74, 19);
            this.lbl_DVT.TabIndex = 17;
            this.lbl_DVT.Text = "Đơn vị tính";
            // 
            // txt_DonViTinh
            // 
            this.txt_DonViTinh.Location = new System.Drawing.Point(940, 37);
            this.txt_DonViTinh.Multiline = true;
            this.txt_DonViTinh.Name = "txt_DonViTinh";
            this.txt_DonViTinh.Size = new System.Drawing.Size(230, 27);
            this.txt_DonViTinh.TabIndex = 16;
            // 
            // lbl_SoLuong
            // 
            this.lbl_SoLuong.AutoSize = true;
            this.lbl_SoLuong.Location = new System.Drawing.Point(859, 91);
            this.lbl_SoLuong.Name = "lbl_SoLuong";
            this.lbl_SoLuong.Size = new System.Drawing.Size(64, 19);
            this.lbl_SoLuong.TabIndex = 15;
            this.lbl_SoLuong.Text = "Số lượng";
            // 
            // txt_SoLuong
            // 
            this.txt_SoLuong.Location = new System.Drawing.Point(940, 83);
            this.txt_SoLuong.Multiline = true;
            this.txt_SoLuong.Name = "txt_SoLuong";
            this.txt_SoLuong.Size = new System.Drawing.Size(230, 27);
            this.txt_SoLuong.TabIndex = 14;
            this.txt_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_SoLuong_KeyPress);
            // 
            // dateTimePicker_NhayNhap
            // 
            this.dateTimePicker_NhayNhap.Location = new System.Drawing.Point(158, 172);
            this.dateTimePicker_NhayNhap.Name = "dateTimePicker_NhayNhap";
            this.dateTimePicker_NhayNhap.Size = new System.Drawing.Size(230, 26);
            this.dateTimePicker_NhayNhap.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Ngày nhập";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(434, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Đơn giá nhập";
            // 
            // txt_DonGiaNhap
            // 
            this.txt_DonGiaNhap.Location = new System.Drawing.Point(555, 175);
            this.txt_DonGiaNhap.Multiline = true;
            this.txt_DonGiaNhap.Name = "txt_DonGiaNhap";
            this.txt_DonGiaNhap.Size = new System.Drawing.Size(230, 27);
            this.txt_DonGiaNhap.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(434, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tên loại mặt hàng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(434, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên mặt hàng";
            // 
            // lbl_manv
            // 
            this.lbl_manv.AutoSize = true;
            this.lbl_manv.Location = new System.Drawing.Point(20, 9);
            this.lbl_manv.Name = "lbl_manv";
            this.lbl_manv.Size = new System.Drawing.Size(72, 13);
            this.lbl_manv.TabIndex = 30;
            this.lbl_manv.Text = "Mã nhân viên";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView_CTnhaphang);
            this.groupBox1.Controls.Add(this.dataGridView_nhaphang);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1320, 415);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách mặt hàng";
            // 
            // dataGridView_CTnhaphang
            // 
            this.dataGridView_CTnhaphang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_CTnhaphang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_CTnhaphang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView_CTnhaphang.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridView_CTnhaphang.Location = new System.Drawing.Point(669, 21);
            this.dataGridView_CTnhaphang.Name = "dataGridView_CTnhaphang";
            this.dataGridView_CTnhaphang.Size = new System.Drawing.Size(648, 391);
            this.dataGridView_CTnhaphang.TabIndex = 1;
            // 
            // dataGridView_nhaphang
            // 
            this.dataGridView_nhaphang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_nhaphang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_nhaphang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridView_nhaphang.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView_nhaphang.Location = new System.Drawing.Point(3, 21);
            this.dataGridView_nhaphang.Name = "dataGridView_nhaphang";
            this.dataGridView_nhaphang.Size = new System.Drawing.Size(647, 391);
            this.dataGridView_nhaphang.TabIndex = 0;
            this.dataGridView_nhaphang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_nhaphang_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "MAPN1";
            this.Column1.HeaderText = "Mã phiếu nhập";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "MANV1";
            this.Column2.HeaderText = "Mã NV";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "TENNSX1";
            this.Column3.HeaderText = "Tên NSX";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "NGAYNHAP1";
            this.Column4.HeaderText = "Ngày nhập";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "SOLUONGMATHANG1";
            this.Column5.HeaderText = "Số lượng MH";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "TONGTIENHANGNHAP1";
            this.Column6.HeaderText = "Tổng tiền ";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "MACTPN1";
            this.Column7.HeaderText = "Mã CTPN";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "MACTPHIEUDATHANG1";
            this.Column8.HeaderText = "Mã CTDH";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "TENMATHANG1";
            this.Column9.HeaderText = "Tên MH";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "SOLUONGMH1";
            this.Column10.HeaderText = "Số lượng";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "THANHTIENCTPNH1";
            this.Column11.HeaderText = "Thành tiền";
            this.Column11.Name = "Column11";
            // 
            // frm_NhapHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_TTCTSanPham);
            this.Controls.Add(this.lbl_manv);
            this.Name = "frm_NhapHang";
            this.Size = new System.Drawing.Size(1370, 749);
            this.Load += new System.EventHandler(this.frm_NhapHang_Load);
            this.groupBox_TTCTSanPham.ResumeLayout(false);
            this.groupBox_TTCTSanPham.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTnhaphang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_nhaphang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_TTCTSanPham;
        private System.Windows.Forms.Button btn_LamMoi;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.ComboBox cbo_TinhTrang;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_DVT;
        private System.Windows.Forms.TextBox txt_DonViTinh;
        private System.Windows.Forms.Label lbl_SoLuong;
        private System.Windows.Forms.TextBox txt_SoLuong;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NhayNhap;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DonGiaNhap;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_manv;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_PhieuNhap;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbo_maPNNSX;
        private System.Windows.Forms.ComboBox cbo_chitietPDNSX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_TenMH;
        private System.Windows.Forms.TextBox txt_TenLoaiMH;
        private System.Windows.Forms.TextBox txt_NSX;
        private System.Windows.Forms.DataGridView dataGridView_CTnhaphang;
        private System.Windows.Forms.DataGridView dataGridView_nhaphang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
    }
}