﻿namespace QuanLy_CH_VLXD
{
    partial class frm_DatHangNSX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MaNV = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_LamMoi = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.cbo_NhaSanXuat = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_DonViTinh = new System.Windows.Forms.TextBox();
            this.lbl_SoLuong = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView_DatHangNSX = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_CTDatHangNSX = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_SoLuong = new System.Windows.Forms.TextBox();
            this.lbl_Ngaylap = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_DonGia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbo_LoaiMH = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbo_MaMH = new System.Windows.Forms.ComboBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.groupBox_TTCTSanPham = new System.Windows.Forms.GroupBox();
            this.txt_MaPDNSX = new System.Windows.Forms.TextBox();
            this.lbl_TienConLaiSo = new System.Windows.Forms.Label();
            this.lbl_TienTraTruocSo = new System.Windows.Forms.Label();
            this.lbl_TongtienSo = new System.Windows.Forms.Label();
            this.txt_TinhTrang = new System.Windows.Forms.TextBox();
            this.btn_Xoa = new System.Windows.Forms.Button();
            this.btn_Sua = new System.Windows.Forms.Button();
            this.btn_Them = new System.Windows.Forms.Button();
            this.lbl_VNDDD = new System.Windows.Forms.Label();
            this.lbl_TienConLai = new System.Windows.Forms.Label();
            this.lbl_VNDD = new System.Windows.Forms.Label();
            this.lbl_VND = new System.Windows.Forms.Label();
            this.lbl_TienTraTruoc = new System.Windows.Forms.Label();
            this.lbl_TongTien = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DatHangNSX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTDatHangNSX)).BeginInit();
            this.groupBox_TTCTSanPham.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_MaNV
            // 
            this.lbl_MaNV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MaNV.Location = new System.Drawing.Point(33, 14);
            this.lbl_MaNV.Name = "lbl_MaNV";
            this.lbl_MaNV.Size = new System.Drawing.Size(53, 19);
            this.lbl_MaNV.TabIndex = 30;
            this.lbl_MaNV.Text = "Ma nv";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 19);
            this.label6.TabIndex = 28;
            this.label6.Text = "Mã phiếu đặt NSX";
            // 
            // btn_LamMoi
            // 
            this.btn_LamMoi.Location = new System.Drawing.Point(692, 225);
            this.btn_LamMoi.Name = "btn_LamMoi";
            this.btn_LamMoi.Size = new System.Drawing.Size(99, 35);
            this.btn_LamMoi.TabIndex = 24;
            this.btn_LamMoi.Text = "Làm mới";
            this.btn_LamMoi.UseVisualStyleBackColor = true;
            this.btn_LamMoi.Click += new System.EventHandler(this.btn_LamMoi_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(906, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 22;
            this.label12.Text = "Tình trạng";
            // 
            // cbo_NhaSanXuat
            // 
            this.cbo_NhaSanXuat.FormattingEnabled = true;
            this.cbo_NhaSanXuat.Location = new System.Drawing.Point(162, 172);
            this.cbo_NhaSanXuat.Name = "cbo_NhaSanXuat";
            this.cbo_NhaSanXuat.Size = new System.Drawing.Size(230, 27);
            this.cbo_NhaSanXuat.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 180);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 18;
            this.label10.Text = "Nhà sản xuất";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(487, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 17;
            this.label9.Text = "Đơn vị tính";
            // 
            // txt_DonViTinh
            // 
            this.txt_DonViTinh.Enabled = false;
            this.txt_DonViTinh.Location = new System.Drawing.Point(587, 82);
            this.txt_DonViTinh.Multiline = true;
            this.txt_DonViTinh.Name = "txt_DonViTinh";
            this.txt_DonViTinh.Size = new System.Drawing.Size(230, 27);
            this.txt_DonViTinh.TabIndex = 16;
            // 
            // lbl_SoLuong
            // 
            this.lbl_SoLuong.AutoSize = true;
            this.lbl_SoLuong.Location = new System.Drawing.Point(487, 134);
            this.lbl_SoLuong.Name = "lbl_SoLuong";
            this.lbl_SoLuong.Size = new System.Drawing.Size(64, 19);
            this.lbl_SoLuong.TabIndex = 15;
            this.lbl_SoLuong.Text = "Số lượng";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView_DatHangNSX);
            this.groupBox1.Controls.Add(this.dataGridView_CTDatHangNSX);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1320, 372);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách mặt hàng";
            // 
            // dataGridView_DatHangNSX
            // 
            this.dataGridView_DatHangNSX.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DatHangNSX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DatHangNSX.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridView_DatHangNSX.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridView_DatHangNSX.Location = new System.Drawing.Point(601, 21);
            this.dataGridView_DatHangNSX.Name = "dataGridView_DatHangNSX";
            this.dataGridView_DatHangNSX.Size = new System.Drawing.Size(716, 348);
            this.dataGridView_DatHangNSX.TabIndex = 1;
            this.dataGridView_DatHangNSX.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DatHangNSX_CellClick);
            this.dataGridView_DatHangNSX.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_DatHangNSX_CellMouseClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "MAPDHNSX1";
            this.Column1.HeaderText = "Mã phiếu đặt";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "MANV1";
            this.Column2.HeaderText = "Mã NV";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "TENNSX1";
            this.Column3.HeaderText = "Tên NSX";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "NGAYLAP1";
            this.Column4.HeaderText = "Ngày lập";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "TONGTIENHANGDAT1";
            this.Column5.HeaderText = "Tổng tiền hàng";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "SOTIENTRATRUOC1";
            this.Column6.HeaderText = "Số tiền trả trước";
            this.Column6.Name = "Column6";
            // 
            // dataGridView_CTDatHangNSX
            // 
            this.dataGridView_CTDatHangNSX.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_CTDatHangNSX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_CTDatHangNSX.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView_CTDatHangNSX.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView_CTDatHangNSX.Location = new System.Drawing.Point(3, 21);
            this.dataGridView_CTDatHangNSX.Name = "dataGridView_CTDatHangNSX";
            this.dataGridView_CTDatHangNSX.Size = new System.Drawing.Size(592, 348);
            this.dataGridView_CTDatHangNSX.TabIndex = 0;
            this.dataGridView_CTDatHangNSX.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_CTDatHangNSX_CellMouseClick);
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "MACTPHIEUDATHANG1";
            this.Column7.HeaderText = "Mã CTPDH";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "TENMATHANG1";
            this.Column8.HeaderText = "Tên mặt hàng";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "SOLUONG1";
            this.Column9.HeaderText = "Số lượng";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "GIA1";
            this.Column10.HeaderText = "Giá";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "THANHTIEN1";
            this.Column11.HeaderText = "Thành tiền";
            this.Column11.Name = "Column11";
            // 
            // txt_SoLuong
            // 
            this.txt_SoLuong.Location = new System.Drawing.Point(587, 126);
            this.txt_SoLuong.Multiline = true;
            this.txt_SoLuong.Name = "txt_SoLuong";
            this.txt_SoLuong.Size = new System.Drawing.Size(230, 27);
            this.txt_SoLuong.TabIndex = 14;
            this.txt_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_SoLuong_KeyPress);
            // 
            // lbl_Ngaylap
            // 
            this.lbl_Ngaylap.AutoSize = true;
            this.lbl_Ngaylap.Location = new System.Drawing.Point(487, 180);
            this.lbl_Ngaylap.Name = "lbl_Ngaylap";
            this.lbl_Ngaylap.Size = new System.Drawing.Size(64, 19);
            this.lbl_Ngaylap.TabIndex = 11;
            this.lbl_Ngaylap.Text = "Ngày lập";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(487, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Đơn giá";
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.Enabled = false;
            this.txt_DonGia.Location = new System.Drawing.Point(587, 36);
            this.txt_DonGia.Multiline = true;
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.Size = new System.Drawing.Size(230, 27);
            this.txt_DonGia.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tên loại mặt hàng";
            // 
            // cbo_LoaiMH
            // 
            this.cbo_LoaiMH.FormattingEnabled = true;
            this.cbo_LoaiMH.Location = new System.Drawing.Point(162, 82);
            this.cbo_LoaiMH.Name = "cbo_LoaiMH";
            this.cbo_LoaiMH.Size = new System.Drawing.Size(230, 27);
            this.cbo_LoaiMH.TabIndex = 6;
            this.cbo_LoaiMH.SelectedValueChanged += new System.EventHandler(this.cbo_LoaiMH_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên mặt hàng";
            // 
            // cbo_MaMH
            // 
            this.cbo_MaMH.FormattingEnabled = true;
            this.cbo_MaMH.Location = new System.Drawing.Point(162, 126);
            this.cbo_MaMH.Name = "cbo_MaMH";
            this.cbo_MaMH.Size = new System.Drawing.Size(230, 27);
            this.cbo_MaMH.TabIndex = 2;
            this.cbo_MaMH.SelectedIndexChanged += new System.EventHandler(this.cbo_MaMH_SelectedIndexChanged);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Enabled = false;
            this.dateTimePicker2.Location = new System.Drawing.Point(587, 172);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(230, 26);
            this.dateTimePicker2.TabIndex = 13;
            // 
            // groupBox_TTCTSanPham
            // 
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_MaPDNSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TienConLaiSo);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TienTraTruocSo);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TongtienSo);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TinhTrang);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Xoa);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Sua);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_Them);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_VNDDD);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TienConLai);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_VNDD);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_VND);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TienTraTruoc);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_TongTien);
            this.groupBox_TTCTSanPham.Controls.Add(this.label6);
            this.groupBox_TTCTSanPham.Controls.Add(this.btn_LamMoi);
            this.groupBox_TTCTSanPham.Controls.Add(this.label12);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_NhaSanXuat);
            this.groupBox_TTCTSanPham.Controls.Add(this.label10);
            this.groupBox_TTCTSanPham.Controls.Add(this.label9);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonViTinh);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.dateTimePicker2);
            this.groupBox_TTCTSanPham.Controls.Add(this.lbl_Ngaylap);
            this.groupBox_TTCTSanPham.Controls.Add(this.label5);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonGia);
            this.groupBox_TTCTSanPham.Controls.Add(this.label3);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_LoaiMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.label2);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_MaMH);
            this.groupBox_TTCTSanPham.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_TTCTSanPham.Location = new System.Drawing.Point(25, 39);
            this.groupBox_TTCTSanPham.Name = "groupBox_TTCTSanPham";
            this.groupBox_TTCTSanPham.Size = new System.Drawing.Size(1320, 286);
            this.groupBox_TTCTSanPham.TabIndex = 3;
            this.groupBox_TTCTSanPham.TabStop = false;
            this.groupBox_TTCTSanPham.Text = "Thông tin mặt hàng";
            this.groupBox_TTCTSanPham.Enter += new System.EventHandler(this.groupBox_TTCTSanPham_Enter);
            // 
            // txt_MaPDNSX
            // 
            this.txt_MaPDNSX.Enabled = false;
            this.txt_MaPDNSX.Location = new System.Drawing.Point(162, 36);
            this.txt_MaPDNSX.Multiline = true;
            this.txt_MaPDNSX.Name = "txt_MaPDNSX";
            this.txt_MaPDNSX.Size = new System.Drawing.Size(230, 27);
            this.txt_MaPDNSX.TabIndex = 47;
            // 
            // lbl_TienConLaiSo
            // 
            this.lbl_TienConLaiSo.AutoSize = true;
            this.lbl_TienConLaiSo.Location = new System.Drawing.Point(1035, 182);
            this.lbl_TienConLaiSo.Name = "lbl_TienConLaiSo";
            this.lbl_TienConLaiSo.Size = new System.Drawing.Size(153, 19);
            this.lbl_TienConLaiSo.TabIndex = 46;
            this.lbl_TienConLaiSo.Text = "100000000000000000";
            // 
            // lbl_TienTraTruocSo
            // 
            this.lbl_TienTraTruocSo.AutoSize = true;
            this.lbl_TienTraTruocSo.Location = new System.Drawing.Point(1035, 136);
            this.lbl_TienTraTruocSo.Name = "lbl_TienTraTruocSo";
            this.lbl_TienTraTruocSo.Size = new System.Drawing.Size(153, 19);
            this.lbl_TienTraTruocSo.TabIndex = 45;
            this.lbl_TienTraTruocSo.Text = "100000000000000000";
            // 
            // lbl_TongtienSo
            // 
            this.lbl_TongtienSo.AutoSize = true;
            this.lbl_TongtienSo.Location = new System.Drawing.Point(1035, 90);
            this.lbl_TongtienSo.Name = "lbl_TongtienSo";
            this.lbl_TongtienSo.Size = new System.Drawing.Size(153, 19);
            this.lbl_TongtienSo.TabIndex = 44;
            this.lbl_TongtienSo.Text = "100000000000000000";
            // 
            // txt_TinhTrang
            // 
            this.txt_TinhTrang.Enabled = false;
            this.txt_TinhTrang.Location = new System.Drawing.Point(1039, 38);
            this.txt_TinhTrang.Multiline = true;
            this.txt_TinhTrang.Name = "txt_TinhTrang";
            this.txt_TinhTrang.Size = new System.Drawing.Size(235, 27);
            this.txt_TinhTrang.TabIndex = 43;
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.Location = new System.Drawing.Point(544, 225);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(99, 35);
            this.btn_Xoa.TabIndex = 42;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.UseVisualStyleBackColor = true;
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // btn_Sua
            // 
            this.btn_Sua.Location = new System.Drawing.Point(405, 225);
            this.btn_Sua.Name = "btn_Sua";
            this.btn_Sua.Size = new System.Drawing.Size(99, 35);
            this.btn_Sua.TabIndex = 41;
            this.btn_Sua.Text = "Sửa";
            this.btn_Sua.UseVisualStyleBackColor = true;
            this.btn_Sua.Click += new System.EventHandler(this.btn_Sua_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.Location = new System.Drawing.Point(265, 225);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(99, 35);
            this.btn_Them.TabIndex = 40;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.UseVisualStyleBackColor = true;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // lbl_VNDDD
            // 
            this.lbl_VNDDD.AutoSize = true;
            this.lbl_VNDDD.Location = new System.Drawing.Point(1231, 175);
            this.lbl_VNDDD.Name = "lbl_VNDDD";
            this.lbl_VNDDD.Size = new System.Drawing.Size(43, 19);
            this.lbl_VNDDD.TabIndex = 39;
            this.lbl_VNDDD.Text = "VND";
            // 
            // lbl_TienConLai
            // 
            this.lbl_TienConLai.AutoSize = true;
            this.lbl_TienConLai.Location = new System.Drawing.Point(906, 180);
            this.lbl_TienConLai.Name = "lbl_TienConLai";
            this.lbl_TienConLai.Size = new System.Drawing.Size(77, 19);
            this.lbl_TienConLai.TabIndex = 38;
            this.lbl_TienConLai.Text = "Tiền còn lại";
            // 
            // lbl_VNDD
            // 
            this.lbl_VNDD.AutoSize = true;
            this.lbl_VNDD.Location = new System.Drawing.Point(1231, 131);
            this.lbl_VNDD.Name = "lbl_VNDD";
            this.lbl_VNDD.Size = new System.Drawing.Size(43, 19);
            this.lbl_VNDD.TabIndex = 36;
            this.lbl_VNDD.Text = "VND";
            // 
            // lbl_VND
            // 
            this.lbl_VND.AutoSize = true;
            this.lbl_VND.Location = new System.Drawing.Point(1231, 87);
            this.lbl_VND.Name = "lbl_VND";
            this.lbl_VND.Size = new System.Drawing.Size(43, 19);
            this.lbl_VND.TabIndex = 35;
            this.lbl_VND.Text = "VND";
            // 
            // lbl_TienTraTruoc
            // 
            this.lbl_TienTraTruoc.AutoSize = true;
            this.lbl_TienTraTruoc.Location = new System.Drawing.Point(906, 136);
            this.lbl_TienTraTruoc.Name = "lbl_TienTraTruoc";
            this.lbl_TienTraTruoc.Size = new System.Drawing.Size(91, 19);
            this.lbl_TienTraTruoc.TabIndex = 34;
            this.lbl_TienTraTruoc.Text = "Tiền trả trước";
            // 
            // lbl_TongTien
            // 
            this.lbl_TongTien.AutoSize = true;
            this.lbl_TongTien.Location = new System.Drawing.Point(906, 90);
            this.lbl_TongTien.Name = "lbl_TongTien";
            this.lbl_TongTien.Size = new System.Drawing.Size(120, 19);
            this.lbl_TongTien.TabIndex = 32;
            this.lbl_TongTien.Text = "Tổng tiền đạt hàng";
            // 
            // frm_DatHangNSX
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_TTCTSanPham);
            this.Controls.Add(this.lbl_MaNV);
            this.Name = "frm_DatHangNSX";
            this.Size = new System.Drawing.Size(1370, 749);
            this.Load += new System.EventHandler(this.frm_DatHangNSX_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DatHangNSX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CTDatHangNSX)).EndInit();
            this.groupBox_TTCTSanPham.ResumeLayout(false);
            this.groupBox_TTCTSanPham.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_MaNV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_LamMoi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbo_NhaSanXuat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_DonViTinh;
        private System.Windows.Forms.Label lbl_SoLuong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_SoLuong;
        private System.Windows.Forms.Label lbl_Ngaylap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DonGia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbo_LoaiMH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbo_MaMH;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.GroupBox groupBox_TTCTSanPham;
        private System.Windows.Forms.Label lbl_TienTraTruoc;
        private System.Windows.Forms.Label lbl_TongTien;
        private System.Windows.Forms.Label lbl_VNDD;
        private System.Windows.Forms.Label lbl_VND;
        private System.Windows.Forms.Button btn_Xoa;
        private System.Windows.Forms.Button btn_Sua;
        private System.Windows.Forms.Button btn_Them;
        private System.Windows.Forms.Label lbl_VNDDD;
        private System.Windows.Forms.Label lbl_TienConLai;
        private System.Windows.Forms.TextBox txt_TinhTrang;
        private System.Windows.Forms.Label lbl_TienConLaiSo;
        private System.Windows.Forms.Label lbl_TienTraTruocSo;
        private System.Windows.Forms.Label lbl_TongtienSo;
        private System.Windows.Forms.DataGridView dataGridView_CTDatHangNSX;
        private System.Windows.Forms.DataGridView dataGridView_DatHangNSX;
        private System.Windows.Forms.TextBox txt_MaPDNSX;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
    }
}