﻿namespace QuanLy_CH_VLXD
{
    partial class frm_DanhMucSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_TimKiemTenMH = new System.Windows.Forms.TextBox();
            this.dateEdit2 = new DevExpress.XtraEditors.DateEdit();
            this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            this.txt_MaMH = new System.Windows.Forms.TextBox();
            this.cbo_TinhTrang = new System.Windows.Forms.ComboBox();
            this.cbo_DonViTinh = new System.Windows.Forms.ComboBox();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_GhiChu = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbo_NhaSX = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_SoLuong = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_DonGia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbo_MaLoaiMH = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_TenloaiMH = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_TenMH = new System.Windows.Forms.TextBox();
            this.groupBox_TTCTSanPham = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
            this.groupBox_TTCTSanPham.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1253, 291);
            this.dataGridView1.TabIndex = 10;
            // 
            // txt_TimKiemTenMH
            // 
            this.txt_TimKiemTenMH.Location = new System.Drawing.Point(181, 36);
            this.txt_TimKiemTenMH.Multiline = true;
            this.txt_TimKiemTenMH.Name = "txt_TimKiemTenMH";
            this.txt_TimKiemTenMH.Size = new System.Drawing.Size(282, 27);
            this.txt_TimKiemTenMH.TabIndex = 8;
            // 
            // dateEdit2
            // 
            this.dateEdit2.EditValue = null;
            this.dateEdit2.Location = new System.Drawing.Point(532, 131);
            this.dateEdit2.Name = "dateEdit2";
            this.dateEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit2.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit2.Size = new System.Drawing.Size(230, 20);
            this.dateEdit2.TabIndex = 32;
            // 
            // dateEdit1
            // 
            this.dateEdit1.EditValue = null;
            this.dateEdit1.Location = new System.Drawing.Point(532, 89);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Size = new System.Drawing.Size(230, 20);
            this.dateEdit1.TabIndex = 32;
            // 
            // txt_MaMH
            // 
            this.txt_MaMH.Location = new System.Drawing.Point(150, 129);
            this.txt_MaMH.Multiline = true;
            this.txt_MaMH.Name = "txt_MaMH";
            this.txt_MaMH.Size = new System.Drawing.Size(230, 27);
            this.txt_MaMH.TabIndex = 31;
            // 
            // cbo_TinhTrang
            // 
            this.cbo_TinhTrang.FormattingEnabled = true;
            this.cbo_TinhTrang.Location = new System.Drawing.Point(876, 226);
            this.cbo_TinhTrang.Name = "cbo_TinhTrang";
            this.cbo_TinhTrang.Size = new System.Drawing.Size(230, 27);
            this.cbo_TinhTrang.TabIndex = 30;
            // 
            // cbo_DonViTinh
            // 
            this.cbo_DonViTinh.FormattingEnabled = true;
            this.cbo_DonViTinh.Location = new System.Drawing.Point(532, 172);
            this.cbo_DonViTinh.Name = "cbo_DonViTinh";
            this.cbo_DonViTinh.Size = new System.Drawing.Size(230, 27);
            this.cbo_DonViTinh.TabIndex = 29;
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(1181, 124);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(99, 35);
            this.btnCapNhat.TabIndex = 27;
            this.btnCapNhat.Text = "Cập nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(1181, 188);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(99, 35);
            this.btnXoa.TabIndex = 26;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(1181, 58);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(99, 35);
            this.btnThem.TabIndex = 24;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(800, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 22;
            this.label12.Text = "Tình trạng";
            // 
            // txt_GhiChu
            // 
            this.txt_GhiChu.Location = new System.Drawing.Point(876, 34);
            this.txt_GhiChu.Multiline = true;
            this.txt_GhiChu.Name = "txt_GhiChu";
            this.txt_GhiChu.Size = new System.Drawing.Size(230, 165);
            this.txt_GhiChu.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(800, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 19);
            this.label11.TabIndex = 20;
            this.label11.Text = "Ghi chú";
            // 
            // cbo_NhaSX
            // 
            this.cbo_NhaSX.FormattingEnabled = true;
            this.cbo_NhaSX.Location = new System.Drawing.Point(532, 218);
            this.cbo_NhaSX.Name = "cbo_NhaSX";
            this.cbo_NhaSX.Size = new System.Drawing.Size(230, 27);
            this.cbo_NhaSX.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(432, 226);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 18;
            this.label10.Text = "Nhà sản xuất";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(432, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 17;
            this.label9.Text = "Đơn vị tính";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 226);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 19);
            this.label8.TabIndex = 15;
            this.label8.Text = "Số lượng";
            // 
            // txt_SoLuong
            // 
            this.txt_SoLuong.Location = new System.Drawing.Point(150, 218);
            this.txt_SoLuong.Multiline = true;
            this.txt_SoLuong.Name = "txt_SoLuong";
            this.txt_SoLuong.Size = new System.Drawing.Size(230, 27);
            this.txt_SoLuong.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(432, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Ngày kết thúc";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(432, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Ngày áp dụng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(432, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Đơn giá";
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.Location = new System.Drawing.Point(532, 34);
            this.txt_DonGia.Multiline = true;
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.Size = new System.Drawing.Size(230, 27);
            this.txt_DonGia.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tên loại mặt hàng";
            // 
            // cbo_MaLoaiMH
            // 
            this.cbo_MaLoaiMH.FormattingEnabled = true;
            this.cbo_MaLoaiMH.Location = new System.Drawing.Point(150, 34);
            this.cbo_MaLoaiMH.Name = "cbo_MaLoaiMH";
            this.cbo_MaLoaiMH.Size = new System.Drawing.Size(230, 27);
            this.cbo_MaLoaiMH.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "Mã loại mặt hàng";
            // 
            // txt_TenloaiMH
            // 
            this.txt_TenloaiMH.Location = new System.Drawing.Point(150, 80);
            this.txt_TenloaiMH.Multiline = true;
            this.txt_TenloaiMH.Name = "txt_TenloaiMH";
            this.txt_TenloaiMH.Size = new System.Drawing.Size(230, 27);
            this.txt_TenloaiMH.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên mặt hàng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã mặt hàng";
            // 
            // txt_TenMH
            // 
            this.txt_TenMH.Location = new System.Drawing.Point(150, 172);
            this.txt_TenMH.Multiline = true;
            this.txt_TenMH.Name = "txt_TenMH";
            this.txt_TenMH.Size = new System.Drawing.Size(230, 27);
            this.txt_TenMH.TabIndex = 0;
            // 
            // groupBox_TTCTSanPham
            // 
            this.groupBox_TTCTSanPham.Controls.Add(this.dateEdit2);
            this.groupBox_TTCTSanPham.Controls.Add(this.dateEdit1);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_MaMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_TinhTrang);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_DonViTinh);
            this.groupBox_TTCTSanPham.Controls.Add(this.btnCapNhat);
            this.groupBox_TTCTSanPham.Controls.Add(this.btnXoa);
            this.groupBox_TTCTSanPham.Controls.Add(this.btnThem);
            this.groupBox_TTCTSanPham.Controls.Add(this.label12);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_GhiChu);
            this.groupBox_TTCTSanPham.Controls.Add(this.label11);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_NhaSX);
            this.groupBox_TTCTSanPham.Controls.Add(this.label10);
            this.groupBox_TTCTSanPham.Controls.Add(this.label9);
            this.groupBox_TTCTSanPham.Controls.Add(this.label8);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_SoLuong);
            this.groupBox_TTCTSanPham.Controls.Add(this.label7);
            this.groupBox_TTCTSanPham.Controls.Add(this.label6);
            this.groupBox_TTCTSanPham.Controls.Add(this.label5);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_DonGia);
            this.groupBox_TTCTSanPham.Controls.Add(this.label3);
            this.groupBox_TTCTSanPham.Controls.Add(this.cbo_MaLoaiMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.label4);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TenloaiMH);
            this.groupBox_TTCTSanPham.Controls.Add(this.label2);
            this.groupBox_TTCTSanPham.Controls.Add(this.label1);
            this.groupBox_TTCTSanPham.Controls.Add(this.txt_TenMH);
            this.groupBox_TTCTSanPham.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_TTCTSanPham.Location = new System.Drawing.Point(25, 21);
            this.groupBox_TTCTSanPham.Name = "groupBox_TTCTSanPham";
            this.groupBox_TTCTSanPham.Size = new System.Drawing.Size(1320, 274);
            this.groupBox_TTCTSanPham.TabIndex = 3;
            this.groupBox_TTCTSanPham.TabStop = false;
            this.groupBox_TTCTSanPham.Text = "Thông tin chi tiết mặt hàng";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 17);
            this.label13.TabIndex = 9;
            this.label13.Text = "Tìm kiếm tên mặt hàng";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txt_TimKiemTenMH);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 313);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1320, 415);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách mặt hàng";
            // 
            // frm_DanhMucSanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox_TTCTSanPham);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_DanhMucSanPham";
            this.Size = new System.Drawing.Size(1370, 749);
            this.Load += new System.EventHandler(this.frm_DanhMucSanPham_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
            this.groupBox_TTCTSanPham.ResumeLayout(false);
            this.groupBox_TTCTSanPham.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_TimKiemTenMH;
        private DevExpress.XtraEditors.DateEdit dateEdit2;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private System.Windows.Forms.TextBox txt_MaMH;
        private System.Windows.Forms.ComboBox cbo_TinhTrang;
        private System.Windows.Forms.ComboBox cbo_DonViTinh;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_GhiChu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbo_NhaSX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_SoLuong;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DonGia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbo_MaLoaiMH;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_TenloaiMH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_TenMH;
        private System.Windows.Forms.GroupBox groupBox_TTCTSanPham;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}