﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Bangghep_NhapHang
    {
        String MAPN;
        String MANV;
        String TENNSX;
        String NGAYNHAP;
        String SOLUONGMATHANG;
        String TONGTIENHANGNHAP;

        public string MAPN1 { get => MAPN; set => MAPN = value; }
        public string MANV1 { get => MANV; set => MANV = value; }
        public string TENNSX1 { get => TENNSX; set => TENNSX = value; }
        public string NGAYNHAP1 { get => NGAYNHAP; set => NGAYNHAP = value; }
        public string SOLUONGMATHANG1 { get => SOLUONGMATHANG; set => SOLUONGMATHANG = value; }
        public string TONGTIENHANGNHAP1 { get => TONGTIENHANGNHAP; set => TONGTIENHANGNHAP = value; }
    }
}
