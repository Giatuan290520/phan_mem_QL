﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public  class CHITIET_HOADON

    {
        String MACTHDB;
        String TENMATHANG;
        String SOLUONGBAN;
        String GIA;
        String THANHTIEN;

        public string MACTHDB1 { get => MACTHDB; set => MACTHDB = value; }
        public string TENMATHANG1 { get => TENMATHANG; set => TENMATHANG = value; }
        public string SOLUONGBAN1 { get => SOLUONGBAN; set => SOLUONGBAN = value; }
        public string GIA1 { get => GIA; set => GIA = value; }
        public string THANHTIEN1 { get => THANHTIEN; set => THANHTIEN = value; }

    }
}
