﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class CT_NhapHang
    {
        String MACTPN;
        String MACTPHIEUDATHANG;
        String TENMATHANG;
        String SOLUONGMH;
        String THANHTIENCTPNH;

        public string MACTPN1 { get => MACTPN; set => MACTPN = value; }
        public string MACTPHIEUDATHANG1 { get => MACTPHIEUDATHANG; set => MACTPHIEUDATHANG = value; }
        public string TENMATHANG1 { get => TENMATHANG; set => TENMATHANG = value; }
        public string SOLUONGMH1 { get => SOLUONGMH; set => SOLUONGMH = value; }
        public string THANHTIENCTPNH1 { get => THANHTIENCTPNH; set => THANHTIENCTPNH = value; }
    }
}
